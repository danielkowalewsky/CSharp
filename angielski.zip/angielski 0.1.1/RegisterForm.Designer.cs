﻿namespace angielski_0._1._1
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            angielski_0._1._1.Office2010Green office2010Green1 = new angielski_0._1._1.Office2010Green();
            this.loginTextBox = new System.Windows.Forms.TextBox();
            this.hasloTextBox = new System.Windows.Forms.TextBox();
            this.mailTextBox = new System.Windows.Forms.TextBox();
            this.imieTextBox = new System.Windows.Forms.TextBox();
            this.powtorzHasloTextBox = new System.Windows.Forms.TextBox();
            this.zamknijPanel = new System.Windows.Forms.Panel();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.rejestracjaButton = new angielski_0._1._1.XButton();
            this.SuspendLayout();
            // 
            // loginTextBox
            // 
            this.loginTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.loginTextBox.Location = new System.Drawing.Point(193, 103);
            this.loginTextBox.Name = "loginTextBox";
            this.loginTextBox.Size = new System.Drawing.Size(242, 22);
            this.loginTextBox.TabIndex = 4;
            // 
            // hasloTextBox
            // 
            this.hasloTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hasloTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hasloTextBox.Location = new System.Drawing.Point(193, 146);
            this.hasloTextBox.Name = "hasloTextBox";
            this.hasloTextBox.Size = new System.Drawing.Size(242, 22);
            this.hasloTextBox.TabIndex = 5;
            this.hasloTextBox.UseSystemPasswordChar = true;
            // 
            // mailTextBox
            // 
            this.mailTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mailTextBox.Location = new System.Drawing.Point(193, 233);
            this.mailTextBox.Name = "mailTextBox";
            this.mailTextBox.Size = new System.Drawing.Size(242, 22);
            this.mailTextBox.TabIndex = 6;
            // 
            // imieTextBox
            // 
            this.imieTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.imieTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.imieTextBox.Location = new System.Drawing.Point(193, 276);
            this.imieTextBox.Name = "imieTextBox";
            this.imieTextBox.Size = new System.Drawing.Size(242, 22);
            this.imieTextBox.TabIndex = 9;
            // 
            // powtorzHasloTextBox
            // 
            this.powtorzHasloTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.powtorzHasloTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.powtorzHasloTextBox.Location = new System.Drawing.Point(193, 188);
            this.powtorzHasloTextBox.Name = "powtorzHasloTextBox";
            this.powtorzHasloTextBox.Size = new System.Drawing.Size(242, 22);
            this.powtorzHasloTextBox.TabIndex = 10;
            this.powtorzHasloTextBox.UseSystemPasswordChar = true;
            // 
            // zamknijPanel
            // 
            this.zamknijPanel.BackColor = System.Drawing.Color.Transparent;
            this.zamknijPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.zamknijPanel.Location = new System.Drawing.Point(398, 3);
            this.zamknijPanel.Name = "zamknijPanel";
            this.zamknijPanel.Size = new System.Drawing.Size(49, 43);
            this.zamknijPanel.TabIndex = 12;
            this.zamknijPanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.zamknijPanel_MouseClick);
            this.zamknijPanel.MouseHover += new System.EventHandler(this.zamknijPanel_MouseHover);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(459, 55);
            this.mainPanel.TabIndex = 14;
            this.mainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDown);
            this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
            this.mainPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseUp);
            // 
            // rejestracjaButton
            // 
            office2010Green1.BorderColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(72)))), ((int)(((byte)(161)))));
            office2010Green1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(135)))), ((int)(((byte)(228)))));
            office2010Green1.ButtonMouseOverColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonMouseOverColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonMouseOverColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(137)))));
            office2010Green1.ButtonMouseOverColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(249)))), ((int)(((byte)(224)))));
            office2010Green1.ButtonNormalColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonNormalColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonSelectedColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonSelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonSelectedColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(117)))));
            office2010Green1.ButtonSelectedColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(216)))), ((int)(((byte)(107)))));
            office2010Green1.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.SelectedTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.TextColor = System.Drawing.Color.White;
            this.rejestracjaButton.ColorTable = office2010Green1;
            this.rejestracjaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rejestracjaButton.Location = new System.Drawing.Point(236, 319);
            this.rejestracjaButton.Name = "rejestracjaButton";
            this.rejestracjaButton.Size = new System.Drawing.Size(199, 54);
            this.rejestracjaButton.TabIndex = 0;
            this.rejestracjaButton.Text = "Zarejestruj";
            this.rejestracjaButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.rejestracjaButton.UseVisualStyleBackColor = true;
            this.rejestracjaButton.Click += new System.EventHandler(this.rejestracjaButton_Click);
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::angielski_0._1._1.Properties.Resources.RegistryFormImage;
            this.ClientSize = new System.Drawing.Size(459, 396);
            this.Controls.Add(this.rejestracjaButton);
            this.Controls.Add(this.zamknijPanel);
            this.Controls.Add(this.powtorzHasloTextBox);
            this.Controls.Add(this.imieTextBox);
            this.Controls.Add(this.mailTextBox);
            this.Controls.Add(this.hasloTextBox);
            this.Controls.Add(this.loginTextBox);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "RegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rejestracja";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox loginTextBox;
        private System.Windows.Forms.TextBox hasloTextBox;
        private System.Windows.Forms.TextBox mailTextBox;
        private System.Windows.Forms.TextBox imieTextBox;
        private System.Windows.Forms.TextBox powtorzHasloTextBox;
        private System.Windows.Forms.Panel zamknijPanel;
        private System.Windows.Forms.Panel mainPanel;
        private XButton rejestracjaButton;
    }
}