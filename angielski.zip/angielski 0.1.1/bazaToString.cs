﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace angielski_0._1._1
{
    public partial class slowo
    {
        public override string ToString()
        {
            bazaClassesDataContext db = new bazaClassesDataContext();
            return String.Format("{0} --> {1}\n", 
                pol, ang);
        }
    }
}
