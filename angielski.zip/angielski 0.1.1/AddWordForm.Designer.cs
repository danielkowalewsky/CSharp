﻿namespace angielski_0._1._1
{
    partial class AddWordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            angielski_0._1._1.Office2010Green office2010Green1 = new angielski_0._1._1.Office2010Green();
            this.tlumPolTextBox = new System.Windows.Forms.TextBox();
            this.tlumAngTextBox = new System.Windows.Forms.TextBox();
            this.tlumPolLabel = new System.Windows.Forms.Label();
            this.tlumAngLabel = new System.Windows.Forms.Label();
            this.listaSlow = new System.Windows.Forms.ListBox();
            this.zamknijPanel = new System.Windows.Forms.Panel();
            this.poziomComboBox = new System.Windows.Forms.ComboBox();
            this.poziomLabel = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.usunButton = new angielski_0._1._1.XButton();
            this.edytujButton = new angielski_0._1._1.XButton();
            this.dodajButton = new angielski_0._1._1.XButton();
            this.SuspendLayout();
            // 
            // tlumPolTextBox
            // 
            this.tlumPolTextBox.Location = new System.Drawing.Point(629, 108);
            this.tlumPolTextBox.Name = "tlumPolTextBox";
            this.tlumPolTextBox.Size = new System.Drawing.Size(101, 20);
            this.tlumPolTextBox.TabIndex = 1;
            this.tlumPolTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tlumPolTextBox_MouseClick);
            this.tlumPolTextBox.TextChanged += new System.EventHandler(this.tlumPolTextBox_TextChanged);
            this.tlumPolTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tlumPolTextBox_KeyDown);
            // 
            // tlumAngTextBox
            // 
            this.tlumAngTextBox.Location = new System.Drawing.Point(629, 137);
            this.tlumAngTextBox.Name = "tlumAngTextBox";
            this.tlumAngTextBox.Size = new System.Drawing.Size(101, 20);
            this.tlumAngTextBox.TabIndex = 2;
            this.tlumAngTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tlumAngTextBox_MouseClick);
            this.tlumAngTextBox.TextChanged += new System.EventHandler(this.tlumAngTextBox_TextChanged);
            this.tlumAngTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tlumAngTextBox_KeyDown);
            // 
            // tlumPolLabel
            // 
            this.tlumPolLabel.AutoSize = true;
            this.tlumPolLabel.BackColor = System.Drawing.Color.Transparent;
            this.tlumPolLabel.Location = new System.Drawing.Point(546, 111);
            this.tlumPolLabel.Name = "tlumPolLabel";
            this.tlumPolLabel.Size = new System.Drawing.Size(69, 13);
            this.tlumPolLabel.TabIndex = 14;
            this.tlumPolLabel.Text = "Tlum. polskie";
            // 
            // tlumAngLabel
            // 
            this.tlumAngLabel.AutoSize = true;
            this.tlumAngLabel.BackColor = System.Drawing.Color.Transparent;
            this.tlumAngLabel.Location = new System.Drawing.Point(532, 140);
            this.tlumAngLabel.Name = "tlumAngLabel";
            this.tlumAngLabel.Size = new System.Drawing.Size(83, 13);
            this.tlumAngLabel.TabIndex = 15;
            this.tlumAngLabel.Text = "Tlum. angielskie";
            // 
            // listaSlow
            // 
            this.listaSlow.FormattingEnabled = true;
            this.listaSlow.Location = new System.Drawing.Point(32, 78);
            this.listaSlow.Name = "listaSlow";
            this.listaSlow.ScrollAlwaysVisible = true;
            this.listaSlow.Size = new System.Drawing.Size(416, 212);
            this.listaSlow.TabIndex = 7;
            this.listaSlow.TabStop = false;
            this.listaSlow.UseTabStops = false;
            this.listaSlow.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listaSlow_MouseClick);
            // 
            // zamknijPanel
            // 
            this.zamknijPanel.BackColor = System.Drawing.Color.Transparent;
            this.zamknijPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.zamknijPanel.Location = new System.Drawing.Point(737, 2);
            this.zamknijPanel.Name = "zamknijPanel";
            this.zamknijPanel.Size = new System.Drawing.Size(47, 46);
            this.zamknijPanel.TabIndex = 17;
            this.zamknijPanel.Click += new System.EventHandler(this.zamknijPanel_Click);
            // 
            // poziomComboBox
            // 
            this.poziomComboBox.BackColor = System.Drawing.Color.White;
            this.poziomComboBox.DisplayMember = "1";
            this.poziomComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.poziomComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.poziomComboBox.FormattingEnabled = true;
            this.poziomComboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.poziomComboBox.Location = new System.Drawing.Point(629, 169);
            this.poziomComboBox.Name = "poziomComboBox";
            this.poziomComboBox.Size = new System.Drawing.Size(44, 21);
            this.poziomComboBox.TabIndex = 3;
            this.poziomComboBox.Tag = "0";
            this.poziomComboBox.ValueMember = "1";
            this.poziomComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.poziomComboBox_KeyDown);
            // 
            // poziomLabel
            // 
            this.poziomLabel.AutoSize = true;
            this.poziomLabel.BackColor = System.Drawing.Color.Transparent;
            this.poziomLabel.Location = new System.Drawing.Point(574, 172);
            this.poziomLabel.Name = "poziomLabel";
            this.poziomLabel.Size = new System.Drawing.Size(41, 13);
            this.poziomLabel.TabIndex = 19;
            this.poziomLabel.Text = "Poziom";
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.Location = new System.Drawing.Point(3, 2);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(794, 49);
            this.mainPanel.TabIndex = 20;
            this.mainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDown);
            this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
            this.mainPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseUp);
            // 
            // usunButton
            // 
            office2010Green1.BorderColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(72)))), ((int)(((byte)(161)))));
            office2010Green1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(135)))), ((int)(((byte)(228)))));
            office2010Green1.ButtonMouseOverColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonMouseOverColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonMouseOverColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(137)))));
            office2010Green1.ButtonMouseOverColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(249)))), ((int)(((byte)(224)))));
            office2010Green1.ButtonNormalColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonNormalColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonSelectedColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonSelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonSelectedColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(117)))));
            office2010Green1.ButtonSelectedColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(216)))), ((int)(((byte)(107)))));
            office2010Green1.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.SelectedTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.TextColor = System.Drawing.Color.White;
            this.usunButton.ColorTable = office2010Green1;
            this.usunButton.Location = new System.Drawing.Point(593, 296);
            this.usunButton.Name = "usunButton";
            this.usunButton.Size = new System.Drawing.Size(127, 26);
            this.usunButton.TabIndex = 6;
            this.usunButton.Text = "Usuń";
            this.usunButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.usunButton.UseVisualStyleBackColor = true;
            this.usunButton.Click += new System.EventHandler(this.usunButton_Click);
            // 
            // edytujButton
            // 
            this.edytujButton.ColorTable = office2010Green1;
            this.edytujButton.Location = new System.Drawing.Point(593, 254);
            this.edytujButton.Name = "edytujButton";
            this.edytujButton.Size = new System.Drawing.Size(127, 26);
            this.edytujButton.TabIndex = 5;
            this.edytujButton.Text = "Edytuj";
            this.edytujButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.edytujButton.UseVisualStyleBackColor = true;
            this.edytujButton.Click += new System.EventHandler(this.edytujButton_Click);
            // 
            // dodajButton
            // 
            this.dodajButton.ColorTable = office2010Green1;
            this.dodajButton.Location = new System.Drawing.Point(593, 213);
            this.dodajButton.Name = "dodajButton";
            this.dodajButton.Size = new System.Drawing.Size(127, 26);
            this.dodajButton.TabIndex = 4;
            this.dodajButton.Text = "Dodaj";
            this.dodajButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.dodajButton.UseVisualStyleBackColor = true;
            this.dodajButton.Click += new System.EventHandler(this.dodajButton_Click);
            // 
            // AddWordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::angielski_0._1._1.Properties.Resources.AddWordImage;
            this.ClientSize = new System.Drawing.Size(796, 354);
            this.Controls.Add(this.zamknijPanel);
            this.Controls.Add(this.usunButton);
            this.Controls.Add(this.edytujButton);
            this.Controls.Add(this.dodajButton);
            this.Controls.Add(this.poziomLabel);
            this.Controls.Add(this.poziomComboBox);
            this.Controls.Add(this.listaSlow);
            this.Controls.Add(this.tlumAngLabel);
            this.Controls.Add(this.tlumPolLabel);
            this.Controls.Add(this.tlumPolTextBox);
            this.Controls.Add(this.tlumAngTextBox);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "AddWordForm";
            this.Text = "Dodaj słowo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tlumPolTextBox;
        private System.Windows.Forms.TextBox tlumAngTextBox;
        private System.Windows.Forms.Label tlumPolLabel;
        private System.Windows.Forms.Label tlumAngLabel;
        private System.Windows.Forms.ListBox listaSlow;
        private System.Windows.Forms.Panel zamknijPanel;
        private System.Windows.Forms.ComboBox poziomComboBox;
        private System.Windows.Forms.Label poziomLabel;
        private XButton dodajButton;
        private XButton edytujButton;
        private XButton usunButton;
        private System.Windows.Forms.Panel mainPanel;
    }
}