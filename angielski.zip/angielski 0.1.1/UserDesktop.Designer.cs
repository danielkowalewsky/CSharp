﻿namespace angielski_0._1._1
{
    partial class UserDesktop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            angielski_0._1._1.Office2010Green office2010Green1 = new angielski_0._1._1.Office2010Green();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.wyjsciePanel = new System.Windows.Forms.Panel();
            this.minimalizePanel = new System.Windows.Forms.Panel();
            this.lpNUD = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.quizRadioButton = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.tlumaczenieGroupBox = new System.Windows.Forms.GroupBox();
            this.typGroupBox = new System.Windows.Forms.GroupBox();
            this.imieLabel = new System.Windows.Forms.Label();
            this.wynikLabel = new System.Windows.Forms.Label();
            this.poziomLabel = new System.Windows.Forms.Label();
            this.startButton = new angielski_0._1._1.XButton();
            this.wyjdzButton = new angielski_0._1._1.XButton();
            this.dodajSlowoButton = new angielski_0._1._1.XButton();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lpNUD)).BeginInit();
            this.tlumaczenieGroupBox.SuspendLayout();
            this.typGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.Controls.Add(this.wyjsciePanel);
            this.mainPanel.Controls.Add(this.minimalizePanel);
            this.mainPanel.Location = new System.Drawing.Point(1, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(700, 52);
            this.mainPanel.TabIndex = 4;
            this.mainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDown);
            this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
            this.mainPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseUp);
            // 
            // wyjsciePanel
            // 
            this.wyjsciePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wyjsciePanel.Location = new System.Drawing.Point(638, 3);
            this.wyjsciePanel.Name = "wyjsciePanel";
            this.wyjsciePanel.Size = new System.Drawing.Size(48, 44);
            this.wyjsciePanel.TabIndex = 1;
            this.wyjsciePanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.wyjsciePanel_MouseClick);
            // 
            // minimalizePanel
            // 
            this.minimalizePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimalizePanel.Location = new System.Drawing.Point(596, 11);
            this.minimalizePanel.Name = "minimalizePanel";
            this.minimalizePanel.Size = new System.Drawing.Size(36, 29);
            this.minimalizePanel.TabIndex = 0;
            this.minimalizePanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minimalizePanel_MouseClick);
            // 
            // lpNUD
            // 
            this.lpNUD.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
            this.lpNUD.Location = new System.Drawing.Point(610, 165);
            this.lpNUD.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.lpNUD.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.lpNUD.Name = "lpNUD";
            this.lpNUD.ReadOnly = true;
            this.lpNUD.Size = new System.Drawing.Size(37, 20);
            this.lpNUD.TabIndex = 6;
            this.lpNUD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lpNUD.ThousandsSeparator = true;
            this.lpNUD.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.lpNUD.ValueChanged += new System.EventHandler(this.lpNUD_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(463, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Liczba slow w quzie:";
            // 
            // quizRadioButton
            // 
            this.quizRadioButton.AutoSize = true;
            this.quizRadioButton.Checked = true;
            this.quizRadioButton.Location = new System.Drawing.Point(16, 19);
            this.quizRadioButton.Name = "quizRadioButton";
            this.quizRadioButton.Size = new System.Drawing.Size(46, 17);
            this.quizRadioButton.TabIndex = 15;
            this.quizRadioButton.TabStop = true;
            this.quizRadioButton.Text = "Quiz";
            this.quizRadioButton.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(91, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(82, 17);
            this.radioButton2.TabIndex = 16;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Wpisywanie";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(16, 19);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(72, 17);
            this.radioButton3.TabIndex = 17;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "POL-ANG";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(99, 19);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(72, 17);
            this.radioButton4.TabIndex = 18;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "ANG-POL";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // tlumaczenieGroupBox
            // 
            this.tlumaczenieGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.tlumaczenieGroupBox.Controls.Add(this.radioButton3);
            this.tlumaczenieGroupBox.Controls.Add(this.radioButton4);
            this.tlumaczenieGroupBox.Location = new System.Drawing.Point(460, 110);
            this.tlumaczenieGroupBox.Name = "tlumaczenieGroupBox";
            this.tlumaczenieGroupBox.Size = new System.Drawing.Size(200, 45);
            this.tlumaczenieGroupBox.TabIndex = 19;
            this.tlumaczenieGroupBox.TabStop = false;
            this.tlumaczenieGroupBox.Text = "Tłumaczenie";
            // 
            // typGroupBox
            // 
            this.typGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.typGroupBox.Controls.Add(this.radioButton2);
            this.typGroupBox.Controls.Add(this.quizRadioButton);
            this.typGroupBox.Location = new System.Drawing.Point(460, 68);
            this.typGroupBox.Name = "typGroupBox";
            this.typGroupBox.Size = new System.Drawing.Size(200, 42);
            this.typGroupBox.TabIndex = 20;
            this.typGroupBox.TabStop = false;
            this.typGroupBox.Text = "Typ zadania";
            // 
            // imieLabel
            // 
            this.imieLabel.AutoSize = true;
            this.imieLabel.BackColor = System.Drawing.Color.Transparent;
            this.imieLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imieLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.imieLabel.Location = new System.Drawing.Point(33, 80);
            this.imieLabel.Name = "imieLabel";
            this.imieLabel.Size = new System.Drawing.Size(94, 38);
            this.imieLabel.TabIndex = 8;
            this.imieLabel.Text = "witaj";
            // 
            // wynikLabel
            // 
            this.wynikLabel.AutoSize = true;
            this.wynikLabel.BackColor = System.Drawing.Color.Transparent;
            this.wynikLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wynikLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.wynikLabel.Location = new System.Drawing.Point(35, 130);
            this.wynikLabel.Name = "wynikLabel";
            this.wynikLabel.Size = new System.Drawing.Size(74, 26);
            this.wynikLabel.TabIndex = 9;
            this.wynikLabel.Text = "wynik";
            // 
            // poziomLabel
            // 
            this.poziomLabel.AutoSize = true;
            this.poziomLabel.BackColor = System.Drawing.Color.Transparent;
            this.poziomLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.poziomLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.poziomLabel.Location = new System.Drawing.Point(35, 166);
            this.poziomLabel.Name = "poziomLabel";
            this.poziomLabel.Size = new System.Drawing.Size(88, 26);
            this.poziomLabel.TabIndex = 10;
            this.poziomLabel.Text = "poziom";
            // 
            // startButton
            // 
            office2010Green1.BorderColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(72)))), ((int)(((byte)(161)))));
            office2010Green1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(135)))), ((int)(((byte)(228)))));
            office2010Green1.ButtonMouseOverColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonMouseOverColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonMouseOverColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(137)))));
            office2010Green1.ButtonMouseOverColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(249)))), ((int)(((byte)(224)))));
            office2010Green1.ButtonNormalColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonNormalColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonSelectedColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonSelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonSelectedColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(117)))));
            office2010Green1.ButtonSelectedColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(216)))), ((int)(((byte)(107)))));
            office2010Green1.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.SelectedTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.TextColor = System.Drawing.Color.White;
            this.startButton.ColorTable = office2010Green1;
            this.startButton.Location = new System.Drawing.Point(265, 256);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(179, 50);
            this.startButton.TabIndex = 14;
            this.startButton.Text = "Start";
            this.startButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // wyjdzButton
            // 
            this.wyjdzButton.ColorTable = office2010Green1;
            this.wyjdzButton.Location = new System.Drawing.Point(481, 256);
            this.wyjdzButton.Name = "wyjdzButton";
            this.wyjdzButton.Size = new System.Drawing.Size(179, 50);
            this.wyjdzButton.TabIndex = 13;
            this.wyjdzButton.Text = "Wyjdz";
            this.wyjdzButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.wyjdzButton.UseVisualStyleBackColor = true;
            this.wyjdzButton.Click += new System.EventHandler(this.wyjdzButton_Click);
            // 
            // dodajSlowoButton
            // 
            this.dodajSlowoButton.ColorTable = office2010Green1;
            this.dodajSlowoButton.Location = new System.Drawing.Point(54, 256);
            this.dodajSlowoButton.Name = "dodajSlowoButton";
            this.dodajSlowoButton.Size = new System.Drawing.Size(179, 50);
            this.dodajSlowoButton.TabIndex = 12;
            this.dodajSlowoButton.Text = "Dodaj slowo";
            this.dodajSlowoButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.dodajSlowoButton.UseVisualStyleBackColor = true;
            this.dodajSlowoButton.Click += new System.EventHandler(this.dodajSlowoButton_Click);
            // 
            // UserDesktop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::angielski_0._1._1.Properties.Resources.UserDesktopImage;
            this.ClientSize = new System.Drawing.Size(699, 329);
            this.Controls.Add(this.typGroupBox);
            this.Controls.Add(this.tlumaczenieGroupBox);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.wyjdzButton);
            this.Controls.Add(this.dodajSlowoButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.poziomLabel);
            this.Controls.Add(this.wynikLabel);
            this.Controls.Add(this.imieLabel);
            this.Controls.Add(this.lpNUD);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "UserDesktop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel użytkownika";
            this.Activated += new System.EventHandler(this.lpNUD_ValueChanged);
            this.Click += new System.EventHandler(this.lpNUD_ValueChanged);
            this.mainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lpNUD)).EndInit();
            this.tlumaczenieGroupBox.ResumeLayout(false);
            this.tlumaczenieGroupBox.PerformLayout();
            this.typGroupBox.ResumeLayout(false);
            this.typGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel wyjsciePanel;
        private System.Windows.Forms.Panel minimalizePanel;
        private System.Windows.Forms.NumericUpDown lpNUD;
        private System.Windows.Forms.Label label1;
        private XButton dodajSlowoButton;
        private XButton wyjdzButton;
        private XButton startButton;
        private System.Windows.Forms.RadioButton quizRadioButton;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox tlumaczenieGroupBox;
        private System.Windows.Forms.GroupBox typGroupBox;
        private System.Windows.Forms.Label imieLabel;
        private System.Windows.Forms.Label wynikLabel;
        private System.Windows.Forms.Label poziomLabel;
    }
}