﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace angielski_0._1._1
{
    public partial class QuizForm : Form
    {     
        bazaClassesDataContext db = new bazaClassesDataContext();
        public List<slowo> listaSlow = new List<slowo>();
        List<slowo> listaOdpowiedzi = new List<slowo>();
        List<slowo> listaPowtTlumaczen = new List<slowo>();
        private uzytkownik p = new uzytkownik();

        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);
        slowo slowoKlucz = new slowo();
        bool polAng;
        int odp = 0;
        int wynik;
        int pomIndex;
        int IndexPoprOdp;
        private int liczbaPytan;
        private int iloscZrobionych = 1;
        bool czyQuiz;

        public QuizForm(uzytkownik p, int lp, bool czyQuiz1, bool czyPolAng)
        {
            InitializeComponent();
            this.p = p;
            wynik = p.wynik;
            polAng = czyPolAng;
            liczbaPytan = lp;
            czyQuiz = czyQuiz1;
            listaSlow = (from x in db.slowos where x.poziom_slowa <= p.poziom_uzytkownika select x).ToList();
            
            if (czyQuiz == false)
            {
                iloscZrobionych = 1;
                ustawSlowo();
                wyborWpisywanie();
            }
            else
            {
                listaOdpowiedzi = (from x in db.slowos select x).ToList();
                ustawQuiz();
            }
            pytanieLabel.Text = ("Pytanie: " + iloscZrobionych.ToString() + "/" + liczbaPytan.ToString());
        }   
        
          
        private void ustawQuiz()
        {
            wynikLabel.Text = p.wynik.ToString();          
            Random rnd = new Random();
            IndexPoprOdp = rnd.Next(listaSlow.Count());
            slowoKlucz = listaSlow.ElementAt(IndexPoprOdp);

            int w1, w2; //indeksy slow z listy do przyciskow odpowiedzi
            listaOdpowiedzi.Clear();
            listaOdpowiedzi = (from x in db.slowos select x).ToList();
            listaOdpowiedzi.RemoveAt(IndexPoprOdp); //unikanie dublowania odpowiedzi na butonach          
            if (polAng == false) //unikanie powtarzania się tych samych slow na buttonach przez takie samie tlumaczenia roznych slow
            {
                listaPowtTlumaczen = (from x in db.slowos where x.ang == slowoKlucz.ang select x).ToList();
                for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
                {
                    listaOdpowiedzi.Remove(listaPowtTlumaczen.ElementAt(i));
                }
            }
            else
            {
                listaPowtTlumaczen = (from x in db.slowos where x.pol == slowoKlucz.pol select x).ToList();
                for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
                {
                    listaOdpowiedzi.Remove(listaPowtTlumaczen.ElementAt(i));
                }
            }

            do
            {
                w1 = rnd.Next(listaOdpowiedzi.Count());
                w2 = rnd.Next(listaOdpowiedzi.Count());
            }
            while (w1 == w2);


            if ( polAng == true ) //z polskiego na angielskie
            {
                slowoKlucz = listaSlow.ElementAt(IndexPoprOdp);
                slowoLabel.Text = listaSlow.ElementAt(IndexPoprOdp).pol;
                List<slowo> ABC = new List<slowo>();
                ABC.Add(listaSlow.ElementAt(IndexPoprOdp));
                ABC.Add(listaOdpowiedzi.ElementAt(w1));
                ABC.Add(listaOdpowiedzi.ElementAt(w2));

                int u1 = rnd.Next(0, 3);
                odpAButton.Text = ABC.ElementAt(u1).ang.ToString();
                ABC.RemoveAt(u1);

                int u2 = rnd.Next(0, 2);
                odpBButton.Text = ABC.ElementAt(u2).ang.ToString();
                ABC.RemoveAt(u2);

                odpCButton.Text = ABC.ElementAt(0).ang.ToString();
                ABC.Clear();

            }
            else if (polAng == false)//z angielskiego na polski
            {
                slowoLabel.Text = listaSlow.ElementAt(IndexPoprOdp).ang;
                List<slowo> ABC = new List<slowo>();
                ABC.Add(listaSlow.ElementAt(IndexPoprOdp));
                ABC.Add(listaOdpowiedzi.ElementAt(w1));
                ABC.Add(listaOdpowiedzi.ElementAt(w2));

                int u1 = rnd.Next(0, 3);
                odpAButton.Text = ABC.ElementAt(u1).pol.ToString();
                ABC.RemoveAt(u1);

                int u2 = rnd.Next(0, 2);
                odpBButton.Text = ABC.ElementAt(u2).pol.ToString();
                ABC.RemoveAt(u2);

                odpCButton.Text = ABC.ElementAt(0).pol.ToString();
                ABC.Clear();
            }
            listaOdpowiedzi.Add(listaSlow.ElementAt(IndexPoprOdp));//użyte słowo może posłużyć jeszcze jako odpowiedź, potrzebne tylko dlatego, że jest mało słow w bazie
           // listaSlow.RemoveAt(IndexPoprOdp); //usuniecie uzytego slowa aby w tym quizie się nie powtórzyło
        }

        void aktualizujLabele()
        {
            if (iloscZrobionych == odp)
            {
                iloscZrobionych++;
            }

            czyKoniec();

            pytanieLabel.Text = ("Pytanie: " + iloscZrobionych.ToString() + "/" + liczbaPytan.ToString());

            for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
            {
                listaOdpowiedzi.Add(listaPowtTlumaczen.ElementAt(i));
            }

        }

        void czyKoniec()
        {
            if (iloscZrobionych == liczbaPytan && czyQuiz == true)
            {
                wynikLabel.Text = p.wynik.ToString();
                pytanieLabel.Text = ("Pytanie: " + iloscZrobionych.ToString() + "/" + liczbaPytan.ToString());
                MessageBox.Show("Koniec testu!", "Gratulacje!");

                Close();
                UserDesktop UD = new UserDesktop(p as uzytkownik);
                UD.Show();
                db.SubmitChanges();
            }
          
           else  if (iloscZrobionych == liczbaPytan+1 && czyQuiz == false )
            {
                wynikLabel.Text = p.wynik.ToString();
                MessageBox.Show("Koniec testu!", "Gratulacje!");

                Close();
                UserDesktop UD = new UserDesktop(p as uzytkownik);
                UD.Show();
                db.SubmitChanges();
            }
            db.SubmitChanges();

        }



        #region Obsługa okna
    
        private void mainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void mainPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void mainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }
        
        private void minimalizePanel_MouseClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void wyjsciePanel_MouseClick(object sender, MouseEventArgs e)
        {
            Close();
            UserDesktop UD = new UserDesktop(p as uzytkownik);
            UD.Show();
            db.SubmitChanges();

        }
        #endregion

        #region Buttony odpowiedzi
        private void odpA_Click(object sender, MouseEventArgs e)
        {
            bool temp = false;
            for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
            {
                if (polAng == false)
                {
                    if (odpAButton.Text == listaPowtTlumaczen.ElementAt(i).pol)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
                else
                {
                    if (odpAButton.Text == listaPowtTlumaczen.ElementAt(i).ang)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
            }

            if (temp == true)
            {
                try
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(pomIndex));
                }
                catch
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(0));
                }
            }
            else
            {
                listaSlow.RemoveAt(IndexPoprOdp);
                IndexPoprOdp = 0;
            }
            aktualizujLabele();
            iloscZrobionych++;

        }

        private void odpBButton_Click(object sender, EventArgs e)
        {
            bool temp = false;

            for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
            {
                if (polAng == false)
                {
                    if (odpBButton.Text == slowoKlucz.pol)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
                else
                {
                    if (odpBButton.Text == slowoKlucz.ang)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
            }
            if (temp == true && iloscZrobionych > 0)
            {
                try
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(pomIndex));
                }
                catch
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(pomIndex-1));
                }
                
            }
            else
            {
                listaSlow.RemoveAt(IndexPoprOdp);
                IndexPoprOdp = 0;
            }
            aktualizujLabele();
            iloscZrobionych++;
        }

        private void odpCButton_Click(object sender, EventArgs e)
        {
            bool temp = false;

            for (int i = 0; i < listaPowtTlumaczen.Count(); i++)
            {
                if (polAng == false)
                {
                    if (odpCButton.Text == slowoKlucz.pol)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
                else
                {
                    if (odpCButton.Text == slowoKlucz.ang)
                    {
                        this.p.wynik += 10;
                        db.SubmitChanges();
                        temp = true;
                        pomIndex = i;
                    }
                    listaPowtTlumaczen.Clear();
                    ustawQuiz();
                }
            }
            if (temp == true)
            {
                try
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(pomIndex));
                }
                catch
                {
                    listaSlow.Remove(listaPowtTlumaczen.ElementAt(pomIndex - 1));
                }
            }
            else
            {
                listaSlow.RemoveAt(IndexPoprOdp);
                IndexPoprOdp = 0;
            }
            aktualizujLabele();
            iloscZrobionych++;
        }
        #endregion
        

        void wyborWpisywanie()
        {
            glownyLabel.Text = "Wpisz tlumaczenie podanego slowa (jako bezokolicznik)";
            odpAButton.Visible = false;
            odpBButton.Visible = false;
            odpCButton.Visible = false;
            
            wynikLabel.Text = p.wynik.ToString();
            pytanieLabel.Text = ("Pytanie: " + iloscZrobionych.ToString() + "/" + liczbaPytan.ToString());
            sprawdzButton.Visible = true;
            odpTextBox.Visible = true;
            pominButton.Visible = true;
        }

        void ustawSlowo()
        {
            Random rand = new Random();
            odp = rand.Next(0, listaSlow.Count());

            if (polAng == true)
            {
                slowoLabel.Text = listaSlow.ElementAt(odp).pol;
            }
            else
            {
                slowoLabel.Text = listaSlow.ElementAt(odp).ang;
            }
           // listaSlow.RemoveAt(odp);
            int r = rand.Next(0, listaSlow.Count());
            slowoLabel.Text = listaSlow.ElementAt(r).pol;
            slowoKlucz = listaSlow.ElementAt(r);

        }

        private void sprawdzButton_Click(object sender, EventArgs e)
        {      
            if (odpTextBox.Text == "")
            {
                odpTextBox.Clear();
            } 
           else if (polAng == true)
            {
                List<slowo> mozliwePoprawneOdp = (from x in db.slowos where x.pol == slowoKlucz.pol select x).ToList();
                for (int i = 0; i < mozliwePoprawneOdp.Count(); i++)
                {
                    if (mozliwePoprawneOdp.ElementAt(i).ang == odpTextBox.Text)
                    {
                        p.wynik += 10;
                    }
                }           
                ustawSlowo();
                iloscZrobionych += 1;
            }
            else
            {
                List<slowo> mozliwePoprawneOdp = (from x in db.slowos where x.ang == slowoKlucz.ang select x).ToList();
                for (int i = 0; i < mozliwePoprawneOdp.Count(); i++)
                {
                    if (mozliwePoprawneOdp.ElementAt(i).pol == odpTextBox.Text)
                    {
                        p.wynik += 10;
                    }
                }  
                ustawSlowo();
                iloscZrobionych += 1;
            }

            pytanieLabel.Text = ("Pytanie: " + iloscZrobionych.ToString() + "/" + liczbaPytan.ToString());
            wynikLabel.Text = p.wynik.ToString();
            czyKoniec();
            odpTextBox.Clear();
            odpTextBox.Focus();
        }

        private void odpTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (odpTextBox.Text == "")
            {
                odpTextBox.Focus();
            }
            else if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                sprawdzButton_Click(sender, e);
            }
        }

        private void pominButton_Click(object sender, EventArgs e)
        {
            wyborWpisywanie();
            ustawSlowo();
            iloscZrobionych += 1;
            czyKoniec();
            odpTextBox.Clear();
            odpTextBox.Focus();
        }
      
    }
}
