﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace angielski_0._1._1
{
    public partial class AddWordForm : Form
    {
        bazaClassesDataContext db = new bazaClassesDataContext();
        private List<slowo> doUsuniecia = new List<slowo>();
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);
        public uzytkownik p;

        public AddWordForm(uzytkownik p)
        {
            InitializeComponent();
            this.p = p;
            wczytaj();
            poziomComboBox.SelectedIndex = 0;
            edytujButton.Enabled = false;
        }
        
        #region Malo istotne rzeczy
        private void listaSlow_Click(object sender, EventArgs e)
        {
            edytujButton.Enabled = true;
            slowo s = listaSlow.SelectedItem as slowo;
            tlumPolTextBox.Text = s.pol;
            tlumAngTextBox.Text = s.ang;
            poziomComboBox.Text = s.poziom_slowa.ToString();
        }

        private void tlumPolTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            tlumPolTextBox.BackColor = Color.White;
            tlumAngTextBox.BackColor = Color.White;
        }

        private void tlumAngTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            tlumPolTextBox.BackColor = Color.White;
            tlumAngTextBox.BackColor = Color.White;
        }
        #endregion

        private void wczytaj()
        {
            listaSlow.Items.Clear();
            listaSlow.Items.AddRange(db.slowos.ToArray());
            tlumPolTextBox.BackColor = Color.White;
            tlumAngTextBox.BackColor = Color.White;
        }


        #region Obsługa buttonów
        private void dodajButton_Click(object sender, EventArgs e)
        {
            string slowo1 = tlumAngTextBox.Text;
            string slowo2 = tlumPolTextBox.Text;

            List<slowo> tlumAng = (from x in db.slowos where x.ang == slowo1 select x).ToList();
            List<slowo> tlumPol = (from x in db.slowos where x.pol == slowo2 select x).ToList();

            if (tlumAngTextBox.Text == "" && tlumPolTextBox.Text == "")
            {
                
            }
            else if ( tlumAngTextBox.Text != "" && tlumPolTextBox.Text != "")
            {
                bool czyDalej = true;
                for (int i = 0; i <tlumAng.Count(); i++)
                {
                    if (tlumAng.ElementAt(i).ang == tlumPolTextBox.Text)
                    {
                        czyDalej = false;
                        break;
                    }
                }

                for (int i = 0; i < tlumPol.Count(); i++)
                {
                    if (tlumPol.ElementAt(i).ang == tlumAngTextBox.Text)
                    {
                        czyDalej = false;
                        break;
                    }
                }
                if (czyDalej == false)
                {
                    tlumPolTextBox.BackColor = Color.IndianRed;
                    tlumAngTextBox.BackColor = Color.IndianRed;
                }
                else
                {
                    slowo nowe = new slowo();

                    nowe.ang = tlumAngTextBox.Text;
                    nowe.pol = tlumPolTextBox.Text;
                    nowe.poziom_slowa = Convert.ToInt32(poziomComboBox.SelectedItem);
                    nowe.id_tworca = p.Id;

                    db.slowos.InsertOnSubmit(nowe);
                    db.SubmitChanges();

                    tlumAngTextBox.Clear();
                    tlumPolTextBox.Clear();
                    
                    wczytaj();
                    tlumPolTextBox.BackColor = Color.LightGreen;
                    tlumAngTextBox.BackColor = Color.LightGreen;
                }
            }
        }

        private void edytujButton_Click(object sender, EventArgs e)
        {
            if (listaSlow.SelectedItem != null)
            {
                slowo s1 = listaSlow.SelectedItem as slowo;

                s1.pol = tlumPolTextBox.Text;
                s1.ang = tlumAngTextBox.Text;
                s1.poziom_slowa = Convert.ToInt32(poziomComboBox.SelectedItem);

                db.SubmitChanges();
                listaSlow.Items.Clear();
                listaSlow.Items.AddRange(db.slowos.ToArray());
            }            
        }

        private void usunButton_Click(object sender, EventArgs e)
        {
            if (listaSlow.SelectedItem != null)
            {
                slowo s = listaSlow.SelectedItem as slowo;
                slowo s1 = (from x in db.slowos where x.id == s.id select x).SingleOrDefault();
                tlumAngTextBox.Text = s.ang;
                db.slowos.DeleteOnSubmit(s1);
                db.SubmitChanges();
                wczytaj();
            }
            tlumAngTextBox.Clear();
            tlumPolTextBox.Clear();
            poziomComboBox.SelectedIndex = 0;
        }
        #endregion


        #region Przesuwanie i obsługa okna
        private void zamknijPanel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void mainPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void mainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }
        #endregion


        #region Przechodzenie enterem między textbox'ami
        private void tlumPolTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                tlumAngTextBox.Focus();
            }
        }

        private void tlumAngTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                poziomComboBox.Focus();
            }
        }

        private void poziomComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                dodajButton_Click(sender, e);
            }
        }
        #endregion


        #region Blokowanie dodajButton
        private void tlumPolTextBox_TextChanged(object sender, EventArgs e)
        {
            string slowo1 = tlumAngTextBox.Text;
            string slowo2 = tlumPolTextBox.Text;
            List<slowo> tlumAng = (from x in db.slowos where x.ang == slowo1 select x).ToList();
            List<slowo> tlumPol = (from x in db.slowos where x.pol == slowo2 select x).ToList();
            bool czyDalej = true;
            for (int i = 0; i < tlumAng.Count(); i++)
            {
                if (tlumAng.ElementAt(i).ang == tlumPolTextBox.Text)
                {
                    czyDalej = false;
                    break;
                }
            }

            for (int i = 0; i < tlumPol.Count(); i++)
            {
                if (tlumPol.ElementAt(i).ang == tlumAngTextBox.Text)
                {
                    czyDalej = false;
                    break;
                }
            }
            if (czyDalej == false)
            {
                dodajButton.Enabled = false;
            }
            else
            {
                dodajButton.Enabled = true;
            }
        }

        private void tlumAngTextBox_TextChanged(object sender, EventArgs e)
        {
            string slowo1 = tlumAngTextBox.Text;
            string slowo2 = tlumPolTextBox.Text;
            List<slowo> tlumAng = (from x in db.slowos where x.ang == slowo1 select x).ToList();
            List<slowo> tlumPol = (from x in db.slowos where x.pol == slowo2 select x).ToList();
            bool czyDalej = true;
            for (int i = 0; i < tlumAng.Count(); i++)
            {
                if (tlumAng.ElementAt(i).ang == tlumPolTextBox.Text)
                {
                    czyDalej = false;
                    break;
                }
            }

            for (int i = 0; i < tlumPol.Count(); i++)
            {
                if (tlumPol.ElementAt(i).ang == tlumAngTextBox.Text)
                {
                    czyDalej = false;
                    break;
                }
            }
            if (czyDalej == false)
            {
                dodajButton.Enabled = false;
            }
            else
            {
                dodajButton.Enabled = true;
            }
        }

        private void listaSlow_MouseClick(object sender, MouseEventArgs e)
        {
            edytujButton.Enabled = true;
            slowo s = listaSlow.SelectedItem as slowo;
            tlumPolTextBox.Text = s.pol;
            tlumAngTextBox.Text = s.ang;
            poziomComboBox.Text = s.poziom_slowa.ToString();
        }
    }
    #endregion
}

