﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace angielski_0._1._1
{
    public partial class UserDesktop : Form
    {
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);
        bazaClassesDataContext db = new bazaClassesDataContext();
        bool czyQuiz;
        bool czyPolAng;
        public uzytkownik p;

        public UserDesktop(uzytkownik p)
        {
            InitializeComponent();
            sprawdzPoziom(p as uzytkownik);
            this.p = p;
            imieLabel.Text = ("Witaj " +p.imie);
            wynikLabel.Text = ("Aktualnie posiadasz: " + p.wynik + "puntków!");
            poziomLabel.Text = ("Poziom, na którym się znajdujesz to: " + p.poziom_uzytkownika);
            
        }

        private void dodajSlowoButton_Click(object sender, EventArgs e)
        {
            AddWordForm adf = new AddWordForm(p as uzytkownik);
            adf.Show();
        }


        private void startButton_Click(object sender, EventArgs e)
        {
            int lpValue = Convert.ToInt32(lpNUD.Value);
            if (quizRadioButton.Checked)
            {
                czyQuiz = true;
            }
            else if (radioButton2.Checked)
            {
                czyQuiz = false;
            }
            if (radioButton3.Checked)
            {
                czyPolAng = true;
            }
            else if (radioButton4.Checked)
            {
                czyPolAng = false; 
            }
            db.SubmitChanges();
            QuizForm q = new QuizForm(p as uzytkownik, lpValue, czyQuiz, czyPolAng);
            q.Show();
            Hide();
        }

        #region Obsluga okna
        private void mainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void mainPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void mainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void minimalizePanel_MouseClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void wyjsciePanel_MouseClick(object sender, MouseEventArgs e)
        {
            Close();
            db.SubmitChanges();
            EntryForm EF = new EntryForm();
            EF.Show();
        }  

        private void wyjdzButton_Click(object sender, EventArgs e)
        {
            this.Close();
            db.SubmitChanges();
            EntryForm r = new EntryForm();
            r.Show();
            db.SubmitChanges();
        }
#endregion

        private void sprawdzPoziom(uzytkownik u)
        {
            bazaClassesDataContext sprPoziom = new bazaClassesDataContext();
            List<poziom> temp = (from x in sprPoziom.pozioms select x).ToList();
            if (u.poziom_uzytkownika < temp.Count())
            {
                for (int i = 1; i < temp.Count(); i++)
                {
                    int a = temp.ElementAt(i).wartosc_odblokowania;
                    if (u.wynik > a)
                    {
                        u.poziom_uzytkownika = u.poziom_uzytkownika + 1;
                    }
                }
            }
            db.SubmitChanges();
        }

        private void lpNUD_ValueChanged(object sender, EventArgs e)
        {
            lpNUD.Maximum = (from x in db.slowos where x.poziom_slowa <= p.poziom_uzytkownika select x).Count() - 2;
        }
    }
}

