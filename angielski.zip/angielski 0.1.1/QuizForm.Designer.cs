﻿namespace angielski_0._1._1
{
    partial class QuizForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.glownyLabel = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.wyjsciePanel = new System.Windows.Forms.Panel();
            this.minimalizePanel = new System.Windows.Forms.Panel();
            this.slowoLabel = new System.Windows.Forms.Label();
            this.punktyTextLabel = new System.Windows.Forms.Label();
            this.wynikLabel = new System.Windows.Forms.Label();
            this.pytanieLabel = new System.Windows.Forms.Label();
            this.odpAButton = new System.Windows.Forms.Button();
            this.odpBButton = new System.Windows.Forms.Button();
            this.odpCButton = new System.Windows.Forms.Button();
            this.odpTextBox = new System.Windows.Forms.TextBox();
            this.sprawdzButton = new System.Windows.Forms.Button();
            this.pominButton = new System.Windows.Forms.Button();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // glownyLabel
            // 
            this.glownyLabel.AutoSize = true;
            this.glownyLabel.BackColor = System.Drawing.Color.Transparent;
            this.glownyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.glownyLabel.Location = new System.Drawing.Point(50, 110);
            this.glownyLabel.Name = "glownyLabel";
            this.glownyLabel.Size = new System.Drawing.Size(580, 20);
            this.glownyLabel.TabIndex = 0;
            this.glownyLabel.Text = "Które z podanych słow jest poprawnym tłumaczeniem podanego słowa?";
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.Controls.Add(this.wyjsciePanel);
            this.mainPanel.Controls.Add(this.minimalizePanel);
            this.mainPanel.Location = new System.Drawing.Point(0, 1);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(700, 52);
            this.mainPanel.TabIndex = 5;
            this.mainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDown);
            this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
            this.mainPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseUp);
            // 
            // wyjsciePanel
            // 
            this.wyjsciePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wyjsciePanel.Location = new System.Drawing.Point(638, 3);
            this.wyjsciePanel.Name = "wyjsciePanel";
            this.wyjsciePanel.Size = new System.Drawing.Size(48, 44);
            this.wyjsciePanel.TabIndex = 1;
            this.wyjsciePanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.wyjsciePanel_MouseClick);
            // 
            // minimalizePanel
            // 
            this.minimalizePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimalizePanel.Location = new System.Drawing.Point(596, 11);
            this.minimalizePanel.Name = "minimalizePanel";
            this.minimalizePanel.Size = new System.Drawing.Size(36, 29);
            this.minimalizePanel.TabIndex = 0;
            this.minimalizePanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minimalizePanel_MouseClick);
            // 
            // slowoLabel
            // 
            this.slowoLabel.AutoSize = true;
            this.slowoLabel.BackColor = System.Drawing.Color.Transparent;
            this.slowoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.slowoLabel.ForeColor = System.Drawing.Color.Blue;
            this.slowoLabel.Location = new System.Drawing.Point(278, 130);
            this.slowoLabel.Name = "slowoLabel";
            this.slowoLabel.Size = new System.Drawing.Size(82, 29);
            this.slowoLabel.TabIndex = 6;
            this.slowoLabel.Text = "slowo";
            // 
            // punktyTextLabel
            // 
            this.punktyTextLabel.AutoSize = true;
            this.punktyTextLabel.BackColor = System.Drawing.Color.Transparent;
            this.punktyTextLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.punktyTextLabel.Location = new System.Drawing.Point(12, 66);
            this.punktyTextLabel.Name = "punktyTextLabel";
            this.punktyTextLabel.Size = new System.Drawing.Size(121, 17);
            this.punktyTextLabel.TabIndex = 7;
            this.punktyTextLabel.Text = "Wszystkie punkty:";
            // 
            // wynikLabel
            // 
            this.wynikLabel.AutoSize = true;
            this.wynikLabel.BackColor = System.Drawing.Color.Transparent;
            this.wynikLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wynikLabel.Location = new System.Drawing.Point(139, 66);
            this.wynikLabel.Name = "wynikLabel";
            this.wynikLabel.Size = new System.Drawing.Size(16, 17);
            this.wynikLabel.TabIndex = 8;
            this.wynikLabel.Text = "0";
            // 
            // pytanieLabel
            // 
            this.pytanieLabel.AutoSize = true;
            this.pytanieLabel.BackColor = System.Drawing.Color.Transparent;
            this.pytanieLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pytanieLabel.Location = new System.Drawing.Point(583, 66);
            this.pytanieLabel.Name = "pytanieLabel";
            this.pytanieLabel.Size = new System.Drawing.Size(59, 17);
            this.pytanieLabel.TabIndex = 10;
            this.pytanieLabel.Text = "Pytanie:";
            // 
            // odpAButton
            // 
            this.odpAButton.Location = new System.Drawing.Point(54, 208);
            this.odpAButton.Name = "odpAButton";
            this.odpAButton.Size = new System.Drawing.Size(157, 53);
            this.odpAButton.TabIndex = 14;
            this.odpAButton.Text = "A";
            this.odpAButton.UseVisualStyleBackColor = true;
            this.odpAButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.odpA_Click);
            // 
            // odpBButton
            // 
            this.odpBButton.Location = new System.Drawing.Point(254, 208);
            this.odpBButton.Name = "odpBButton";
            this.odpBButton.Size = new System.Drawing.Size(157, 53);
            this.odpBButton.TabIndex = 15;
            this.odpBButton.Text = "B";
            this.odpBButton.UseVisualStyleBackColor = true;
            this.odpBButton.Click += new System.EventHandler(this.odpBButton_Click);
            // 
            // odpCButton
            // 
            this.odpCButton.Location = new System.Drawing.Point(455, 208);
            this.odpCButton.Name = "odpCButton";
            this.odpCButton.Size = new System.Drawing.Size(157, 53);
            this.odpCButton.TabIndex = 16;
            this.odpCButton.Text = "C";
            this.odpCButton.UseVisualStyleBackColor = true;
            this.odpCButton.Click += new System.EventHandler(this.odpCButton_Click);
            // 
            // odpTextBox
            // 
            this.odpTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odpTextBox.Location = new System.Drawing.Point(254, 208);
            this.odpTextBox.Name = "odpTextBox";
            this.odpTextBox.Size = new System.Drawing.Size(157, 26);
            this.odpTextBox.TabIndex = 1;
            this.odpTextBox.Visible = false;
            this.odpTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.odpTextBox_KeyDown);
            // 
            // sprawdzButton
            // 
            this.sprawdzButton.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sprawdzButton.Location = new System.Drawing.Point(417, 209);
            this.sprawdzButton.Name = "sprawdzButton";
            this.sprawdzButton.Size = new System.Drawing.Size(138, 26);
            this.sprawdzButton.TabIndex = 2;
            this.sprawdzButton.Text = "Sprawdź";
            this.sprawdzButton.UseVisualStyleBackColor = true;
            this.sprawdzButton.Visible = false;
            this.sprawdzButton.Click += new System.EventHandler(this.sprawdzButton_Click);
            // 
            // pominButton
            // 
            this.pominButton.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pominButton.Location = new System.Drawing.Point(417, 241);
            this.pominButton.Name = "pominButton";
            this.pominButton.Size = new System.Drawing.Size(138, 26);
            this.pominButton.TabIndex = 17;
            this.pominButton.Text = "Pomiń słowo";
            this.pominButton.UseVisualStyleBackColor = true;
            this.pominButton.Visible = false;
            this.pominButton.Click += new System.EventHandler(this.pominButton_Click);
            // 
            // QuizForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::angielski_0._1._1.Properties.Resources.QuizFormImage;
            this.ClientSize = new System.Drawing.Size(699, 317);
            this.Controls.Add(this.pominButton);
            this.Controls.Add(this.sprawdzButton);
            this.Controls.Add(this.odpTextBox);
            this.Controls.Add(this.odpCButton);
            this.Controls.Add(this.odpBButton);
            this.Controls.Add(this.odpAButton);
            this.Controls.Add(this.pytanieLabel);
            this.Controls.Add(this.wynikLabel);
            this.Controls.Add(this.punktyTextLabel);
            this.Controls.Add(this.slowoLabel);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.glownyLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "QuizForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quiz";
            this.mainPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label glownyLabel;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel wyjsciePanel;
        private System.Windows.Forms.Panel minimalizePanel;
        private System.Windows.Forms.Label slowoLabel;
        private System.Windows.Forms.Label punktyTextLabel;
        private System.Windows.Forms.Label wynikLabel;
        private System.Windows.Forms.Label pytanieLabel;
        private System.Windows.Forms.Button odpAButton;
        private System.Windows.Forms.Button odpBButton;
        private System.Windows.Forms.Button odpCButton;
        private System.Windows.Forms.TextBox odpTextBox;
        private System.Windows.Forms.Button sprawdzButton;
        private System.Windows.Forms.Button pominButton;
    }
}