﻿namespace angielski_0._1._1
{
    partial class EntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            angielski_0._1._1.Office2010Green office2010Green1 = new angielski_0._1._1.Office2010Green();
            this.uzytkownikTextBox = new System.Windows.Forms.TextBox();
            this.hasloTextBox = new System.Windows.Forms.TextBox();
            this.rejestracjaPanel = new System.Windows.Forms.Panel();
            this.wyjsciePanel = new System.Windows.Forms.Panel();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.logujButton = new angielski_0._1._1.XButton();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // uzytkownikTextBox
            // 
            this.uzytkownikTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.uzytkownikTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.uzytkownikTextBox.Location = new System.Drawing.Point(131, 91);
            this.uzytkownikTextBox.Name = "uzytkownikTextBox";
            this.uzytkownikTextBox.Size = new System.Drawing.Size(208, 28);
            this.uzytkownikTextBox.TabIndex = 1;
            this.uzytkownikTextBox.Text = "root";
            this.uzytkownikTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.uzytkownikTextBox_KeyDown);
            // 
            // hasloTextBox
            // 
            this.hasloTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hasloTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hasloTextBox.Location = new System.Drawing.Point(131, 153);
            this.hasloTextBox.Name = "hasloTextBox";
            this.hasloTextBox.Size = new System.Drawing.Size(208, 25);
            this.hasloTextBox.TabIndex = 2;
            this.hasloTextBox.Text = "qwerty";
            this.hasloTextBox.UseSystemPasswordChar = true;
            this.hasloTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.hasloTextBox_KeyDown);
            // 
            // rejestracjaPanel
            // 
            this.rejestracjaPanel.BackColor = System.Drawing.Color.Transparent;
            this.rejestracjaPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rejestracjaPanel.Location = new System.Drawing.Point(13, 223);
            this.rejestracjaPanel.Name = "rejestracjaPanel";
            this.rejestracjaPanel.Size = new System.Drawing.Size(108, 27);
            this.rejestracjaPanel.TabIndex = 4;
            this.rejestracjaPanel.Click += new System.EventHandler(this.rejestracjaPanel_Click);
            // 
            // wyjsciePanel
            // 
            this.wyjsciePanel.BackColor = System.Drawing.Color.Transparent;
            this.wyjsciePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wyjsciePanel.Location = new System.Drawing.Point(305, 5);
            this.wyjsciePanel.Name = "wyjsciePanel";
            this.wyjsciePanel.Size = new System.Drawing.Size(51, 41);
            this.wyjsciePanel.TabIndex = 11;
            this.wyjsciePanel.Click += new System.EventHandler(this.wyjsciePanel_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.Controls.Add(this.wyjsciePanel);
            this.mainPanel.Location = new System.Drawing.Point(2, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(370, 52);
            this.mainPanel.TabIndex = 12;
            this.mainPanel.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDoubleClick);
            this.mainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseDown);
            this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
            this.mainPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseUp);
            // 
            // logujButton
            // 
            office2010Green1.BorderColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(72)))), ((int)(((byte)(161)))));
            office2010Green1.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(135)))), ((int)(((byte)(228)))));
            office2010Green1.ButtonMouseOverColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonMouseOverColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonMouseOverColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(137)))));
            office2010Green1.ButtonMouseOverColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(249)))), ((int)(((byte)(224)))));
            office2010Green1.ButtonNormalColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonNormalColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(126)))), ((int)(((byte)(43)))));
            office2010Green1.ButtonNormalColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(184)))), ((int)(((byte)(67)))));
            office2010Green1.ButtonSelectedColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(199)))), ((int)(((byte)(87)))));
            office2010Green1.ButtonSelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            office2010Green1.ButtonSelectedColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(117)))));
            office2010Green1.ButtonSelectedColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(216)))), ((int)(((byte)(107)))));
            office2010Green1.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.SelectedTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            office2010Green1.TextColor = System.Drawing.Color.White;
            this.logujButton.ColorTable = office2010Green1;
            this.logujButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.logujButton.Location = new System.Drawing.Point(206, 206);
            this.logujButton.Name = "logujButton";
            this.logujButton.Size = new System.Drawing.Size(133, 44);
            this.logujButton.TabIndex = 3;
            this.logujButton.Text = "Zaloguj";
            this.logujButton.Theme = angielski_0._1._1.Theme.MSOffice2010_Green;
            this.logujButton.UseVisualStyleBackColor = true;
            this.logujButton.Click += new System.EventHandler(this.logujButton_Click);
            // 
            // EntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::angielski_0._1._1.Properties.Resources.EntryFormImage;
            this.ClientSize = new System.Drawing.Size(367, 288);
            this.ControlBox = false;
            this.Controls.Add(this.logujButton);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.rejestracjaPanel);
            this.Controls.Add(this.hasloTextBox);
            this.Controls.Add(this.uzytkownikTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "EntryForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Logowanie";
            this.mainPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox uzytkownikTextBox;
        private System.Windows.Forms.TextBox hasloTextBox;
        private System.Windows.Forms.Panel rejestracjaPanel;
        private System.Windows.Forms.Panel wyjsciePanel;
        private System.Windows.Forms.Panel mainPanel;
        private XButton logujButton;
    }
}

