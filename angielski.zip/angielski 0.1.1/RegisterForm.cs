﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace angielski_0._1._1
{
    public partial class RegisterForm : Form
    {
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        public RegisterForm()
        {
            InitializeComponent();
        }
        private void rejestracjaButton_Click(object sender, EventArgs e)
        {
            bazaClassesDataContext db = new bazaClassesDataContext();
            uzytkownik u = new uzytkownik();
            string login = loginTextBox.Text;
            string haslo = hasloTextBox.Text;
            string mail = mailTextBox.Text;

            if (login == "")
            {
                MessageBox.Show("Pole login musi być wypełnione!");
            }
            else if (haslo == "")
            {
                MessageBox.Show("Pole haslo musi być wypełnione!");
            }
            else if (mail == "")
            {
                MessageBox.Show("Pole z e-mailem musi być wypełnione!");
            }
            else
            {
                var sprawdzLogin = (from x in db.uzytkowniks where x.login == login select x);
                if (sprawdzLogin.Count() != 0)
                {
                    MessageBox.Show("Użytkownik z takim loginem już istnieje!");
                }
                else if (hasloTextBox.Text != powtorzHasloTextBox.Text)
                {
                    MessageBox.Show("Hasła się nie zgadzają!");
                    hasloTextBox.Clear();
                    powtorzHasloTextBox.Clear();
                }
                else
                {
                    u.login = loginTextBox.Text;
                    u.haslo = hasloTextBox.Text;
                    u.mail = mailTextBox.Text;
                    u.imie = imieTextBox.Text;
                    u.poziom_uzytkownika = 1;
                    db.uzytkowniks.InsertOnSubmit(u);
                    db.SubmitChanges();
                    MessageBox.Show("Rejestracja zakonczona sukcesem!", "Gratulacje!");
                    Close();
                }
            }
        }

        private void zamknijPanel_MouseClick(object sender, MouseEventArgs e)
        {
            Close();
        }

        #region Przenoszenie okna
        private void mainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void mainPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void mainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void zamknijPanel_MouseHover(object sender, EventArgs e)
        {
            
        }
        #endregion

    }
}

