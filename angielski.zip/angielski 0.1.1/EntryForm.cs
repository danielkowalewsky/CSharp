﻿using System;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace angielski_0._1._1
{
    public partial class EntryForm : Form
    {
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        public EntryForm()
        {
            InitializeComponent();
        }


        private void rejestracjaPanel_Click(object sender, EventArgs e)
        {
            RegisterForm r = new RegisterForm();
            r.Show();
        }

        private void wyjsciePanel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void uzytkownikTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                hasloTextBox.Focus();
            }
        }

        private void hasloTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                logujButton_Click(sender, e);
            }
        }

        private void mainPanel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void logujButton_Click(object sender, EventArgs e)
        {
            bazaClassesDataContext db = new bazaClassesDataContext();
            string login = uzytkownikTextBox.Text;
            string haslo = hasloTextBox.Text;

            if (login == "")
            {
                MessageBox.Show("Pole login musi być wypełnione!", "Błąd!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else if (haslo == "")
            {
                MessageBox.Show("Pole haslo musi być wypełnione!", "Błąd!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                var sprawdzUzytkownika = (from x in db.uzytkowniks where x.login == login select x);
                var sprawdzHaslo = (from x in db.uzytkowniks where x.haslo == haslo && x.login == login select x);

                if (sprawdzUzytkownika.Count() != 1)
                {
                    MessageBox.Show("Użytkownik z takim loginem nie istnieje!", "Błąd!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    uzytkownikTextBox.Clear();
                    hasloTextBox.Clear();

                }

                else if (sprawdzHaslo.Count() != 1)
                {
                    MessageBox.Show("Błędne hasło", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    hasloTextBox.Clear();
                }

                else
                {
                    var log = (from x in db.uzytkowniks where x.login == login select x).SingleOrDefault();
                    Hide();
                    UserDesktop ud = new UserDesktop(log as uzytkownik);
                    ud.Show();
                }
            }
        }

        private void mainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void mainPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void mainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true; 
            _start_point = new Point(e.X, e.Y);
        }
    }

    }

